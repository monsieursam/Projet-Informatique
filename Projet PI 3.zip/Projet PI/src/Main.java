import interfaceGraphique.*;
public class Main {
	public static void main(String [] args){
		Fenetre a = new Fenetre();
	}
}
