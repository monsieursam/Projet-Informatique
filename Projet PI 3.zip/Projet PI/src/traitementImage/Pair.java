package traitementImage;

public class Pair<X,Y> {

	X first;
	Y second;

	public Pair(X first, Y second) {
		this.first = first;
		this.second = second;
	}

}
